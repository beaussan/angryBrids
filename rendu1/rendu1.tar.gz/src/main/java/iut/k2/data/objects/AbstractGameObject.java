package iut.k2.data.objects;

import java.awt.*;

/**
 * Created by Nicolas Beaussart on 12/10/15 for angryBrids.
 */
public abstract class AbstractGameObject {


    public abstract void render(Graphics batch);
}
