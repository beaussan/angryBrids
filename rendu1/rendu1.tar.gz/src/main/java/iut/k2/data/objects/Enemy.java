package iut.k2.data.objects;

import iut.k2.physics.Coordinate2D;

import java.awt.*;

public class Enemy extends Entity {

	public Enemy(Coordinate2D c) {
		super(c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void render(Graphics batch) {

	}

	@Override
	public void update(float deltaTime) {

	}

}
