package iut.k2;

/**
 * Created by Nicolas Beaussart on 13/10/15 for angryBrids.
 */
public class Constants {
    public static final int SIZE_HEIGHT = 600;
    public static final int SIZE_WIDE = 800;
}
